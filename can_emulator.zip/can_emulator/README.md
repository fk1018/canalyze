# Can Emulator
## Description
The purpose of this code is to send messages to the can bus