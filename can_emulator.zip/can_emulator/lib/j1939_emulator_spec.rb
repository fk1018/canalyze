# frozen_string_literal: true

# j1939_emulator_spec.rb
require 'j1939_emulator'
require 'rspec'

describe J1939Emulator do
  let(:emulator_instance) { described_class.new }

  describe '#initialize' do
    it 'creates an instance without error' do
      expect { emulator_instance }.not_to raise_error
    end

    it 'returns nil' do
      expect(emulator_instance).to be_an_instance_of(described_class)
    end
  end

  describe '#start' do
    it 'should print starting message' do
      obj = J1939Emulator.new
      expect { obj.start }.to output("Starting J1939Emulator\n").to_stdout
    end
  end
end
